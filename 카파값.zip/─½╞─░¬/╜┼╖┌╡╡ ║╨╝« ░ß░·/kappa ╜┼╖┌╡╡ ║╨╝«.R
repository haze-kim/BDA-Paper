options(encoding = 'UTF-8')

getwd()
setwd("/Users/kms01/Desktop/데이터분석 기초/kappa 신뢰도 분석")
dir()

install.packages("readxl")
library(readxl)
CodingResult <- read_excel("신뢰도 분석;간략.xlsx", sheet=1)
CodingResult_df <- as.data.frame(CodingResult)
CodingResult_df_cleaned <- CodingResult_df[,c(1,2)]
data <- cbind(CodingResult_df_cleaned$김혜정, CodingResult_df_cleaned$김민서)
data

install.packages("psych")
library(psych)
result <- cohen.kappa(data)
result
  