options(encoding = 'UTF-8')

getwd()
setwd("/Users/kms01/Desktop/데이터분석 기초/네트워크/네트워크 만들기")
dir()

install.packages("visNetwork")
library(visNetwork, quietly=TRUE)
install.packages("readxl")
library(readxl)

node <- read_excel("networknodes.xlsx")
colnames(node) <- c("id","label","group")
edges <- read_excel("networkedges.xlsx")
edge <- edges[,c(2,3)]
network2 <- visNetwork(node, edge, main="평가요소에 따른 강의 간 관계성", height = "700px", width = "100%") %>% visLegend() %>% visOptions(selectedBy = "group", highlightNearest = TRUE, nodesIdSelection = TRUE) %>% visPhysics(stabilization = FALSE)
network2

visSave(networkgenerated, file = "network2.html", background = "white")
